const APIReducer = (state: any, action: any) => {};

export default APIReducer;
